1.Worked on the student.html file

- Added Filter Form: With Submit and Reset Buttons.
- Whenever, a keyword is entered by the user(the text input),
 it will search for that particular keyword and then shows the desired output.
- Added checkbox: With gender selection.
- It will give the result as the selection is made by the user whether it is male or female.
- Used these inputs to filter the data. 

2.Worked on the student.js file with rendering the table using id,gender,studentname,major and enrollmentdate.

3. Ouptut without filter

![image info](output-without-filter.jpeg)

4. Output with filter

![image info](output-with-filter.jpeg)
